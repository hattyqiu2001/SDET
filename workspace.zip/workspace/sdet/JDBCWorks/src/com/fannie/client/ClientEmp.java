package com.fannie.client;

import com.fannie.bean.Employee;
import com.fannie.dao.EmployeeDAO;
import com.fannie.interfaces.IEmployeeDAO;

public class ClientEmp {
	public static void main(String[] args) {
		IEmployeeDAO dao = new EmployeeDAO();

	/*	System.out.println(dao.insertEmployee(
			new Employee(" Suresh", 223344, "Suresh@fanniemae.com")));
			*/
		
	
		/*
		Employee[] empA = new Employee [4];
		empA[0] = new Employee("Hatty",2000, "21@yahoo.com");
		empA[1] = new Employee("Sam",3000, "S@yahoo.com");
		empA[2] = new Employee("Barry",5000, "B@yahoo.com");
		empA[3] = new Employee("Larry",5000, "Lr@yahoo.com");*/
		
		
	for(Employee temp : dao.getAllEmps()){
		System.out.println(temp);
	}
		
		//System.out.println(dao.deleteEmp(2));
		//System.out.println(dao.getEmp(10));
	}
}