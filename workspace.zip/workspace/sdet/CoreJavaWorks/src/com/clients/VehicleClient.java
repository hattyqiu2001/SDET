package com.clients;

import com.fannie.inhe.Car;
import com.fannie.inhe.FourWheeler;
import com.fannie.inhe.Jeep;
import com.fannie.inhe.Vehicle;

public class VehicleClient {
	public static void main(String[] args) {
		Vehicle [] vehicles = new Vehicle[5];
		
		vehicles [0] = new Car("BMW");
		vehicles [1] = new Jeep("Audi", 2);
		vehicles [2] = new Car("Toyota");
		vehicles [3] = new Jeep("MB", 4);
		vehicles [4] = new Car("BMW");
	
		for (Vehicle temp: vehicles){
		System.out.println("---------------");
		temp.move();
		((FourWheeler)temp).steering();
		if (temp instanceof Car){
			System.out.println("Car make :"+ ((Car)temp).getModel());

			
		}else if (temp instanceof Jeep){
			System.out.println("Jeep make : "+ ((Jeep)temp).getModel());
			System.out.println("Jeep doors : " + ((Jeep)temp).getDoors());
		}
		
		
		}
	}

}
