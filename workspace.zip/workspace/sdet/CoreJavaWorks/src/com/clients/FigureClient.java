package com.clients;

import com.fannie.abs.Circle;
import com.fannie.abs.Figure;
import com.fannie.abs.Rectangle;

public class FigureClient {
	public static void main(String args[]) {

		Figure[] figures = new Figure[4];
		figures[0] = new Rectangle(10, 20);
		figures[1] = new Circle(15);
		figures[2] = new Rectangle(5, 10);
		figures[3] = new Circle(20);
		
		new FigureBL().display(figures);
	}
}
