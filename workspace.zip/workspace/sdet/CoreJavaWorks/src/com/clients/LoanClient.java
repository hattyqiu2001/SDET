package com.clients;


import com.fannie.interfaces.HomeLoan;
import com.fannie.interfaces.Loan;
import com.fannie.interfaces.PersonalLoan;

public class LoanClient {
	public static void main(String[] args) {
		Loan [] loans = new Loan[4];
		loans[0] = new HomeLoan(0);
		
		loans[1] = new PersonalLoan(0);
		loans[2] = new HomeLoan(1000);
		
		loans[3] = new PersonalLoan(1200);
		
			for (Loan temp: loans){
				System.out.println("-------------------");
				temp.submitLoan();
				temp.foreclosure();
				temp.foreclosure(2000);
			}
	
}
}
