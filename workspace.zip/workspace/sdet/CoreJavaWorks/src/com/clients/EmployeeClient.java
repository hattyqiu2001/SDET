package com.clients;

import com.fannie.Employee;

public class EmployeeClient {
	public static void main(String args[]){
		Employee emp1;
		emp1 = new Employee();
		emp1.setEmpId(100);
		emp1.setEmpName("Sco");
		emp1.setEmpSal(11000);
		System.out.println("empId "+ emp1.getEmpId());
		System.out.println("empName " + emp1.getEmpName());
		System.out.println("empSal " + emp1.getEmpSal());
		
	}

}
