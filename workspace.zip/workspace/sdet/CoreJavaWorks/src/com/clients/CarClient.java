package com.clients;

import com.fannie.inhe.Car;

public class CarClient {
	public static void main(String[] args) {
		Car bmw = new Car("BMW");
		//bmw.setModel("BMW");
		System.out.println(bmw.getModel());
		bmw.steering();
		bmw.move();
	}
}
