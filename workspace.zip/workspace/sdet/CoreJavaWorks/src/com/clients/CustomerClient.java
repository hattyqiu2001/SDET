package com.clients;

import com.fannie.Customer;
import com.fannie.Name;

public class CustomerClient {
	public static void main(String[] args) {
		Customer cust = new Customer();
				cust.setcID(101);
		Name name = new Name();
		name.setfName("Peter");
		name.setlName("Harry");
		name.setmName("Mary");
		cust.setName(name);
		cust.setSal(10000);
		System.out.println(cust);	
		
	}


}
