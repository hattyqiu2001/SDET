package com.clients;

import com.fannie.abs.Figure;

public class FigureBL {
	public void display(Figure [] figures){
		for (Figure temp : figures){
			temp.area();
			temp.draw();
		}
	}

}

