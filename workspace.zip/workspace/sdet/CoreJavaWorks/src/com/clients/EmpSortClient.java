package com.clients;

import java.util.Arrays;
import java.util.Comparator;

import com.fannie.interfaces.Emp;
import com.fannie.interfaces.EmpSorter;

public class EmpSortClient {
	public static void main(String[] args) {
		Emp [] emps = {
				new Emp(101, "Amit", 20000),
				new Emp(102, "Andy", 30000),
				new Emp(109, "Sally", 40000),
				new Emp(104, "Jack", 50000)
		};
		for (Emp temp: emps){
			System.out.println(temp);
		}
		
		Arrays.sort(emps, new EmpSorter());
		
		
		Arrays.sort(emps, new Comparator<Emp>() {

			@Override
			public int compare(Emp arg0, Emp arg1) {
				return arg0.getEmpName().compareTo(arg1.getEmpName());
			}
		});
		System.out.println("-----------------------");
		System.out.println("after sort");
		for (Emp temp: emps){
			System.out.println(temp);
		}
		
	}
}	
