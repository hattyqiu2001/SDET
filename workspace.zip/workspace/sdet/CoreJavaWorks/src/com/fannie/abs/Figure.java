package com.fannie.abs;

public abstract class Figure {
	public final double PI = 3.14;
	public abstract void area();
	public void draw(){
		System.out.println("Can be drawn with pen/pencil");
	}

}
