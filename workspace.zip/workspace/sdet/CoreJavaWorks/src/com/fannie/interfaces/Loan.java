package com.fannie.interfaces;

public interface Loan {
	void submitLoan();
	void loanAmount();
	void foreclosure();
	void foreclosure(int amount);

}
