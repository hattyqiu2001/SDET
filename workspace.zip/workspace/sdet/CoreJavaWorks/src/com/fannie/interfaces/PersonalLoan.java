package com.fannie.interfaces;

public class PersonalLoan implements Loan{
	int loanAmount;
	
	public PersonalLoan(int loanAmount) {
		super();
		this.loanAmount = loanAmount;
	}

	@Override
	public void submitLoan() {
		System.out.println("Personal Loan submitted");
	}

	@Override
	public void loanAmount() {
		System.out.println("Personal loan amount " + loanAmount);
	}

	@Override
	public void foreclosure() {
		System.out.println("Personal loan foreclosure applied");		
	}

	@Override
	public void foreclosure(int amount) {
		System.out.println("Personal loan foreclosure applied with " + loanAmount);	
	}

}
