package com.fannie.interfaces;

import java.util.Comparator;

public class EmpSorter implements Comparator<Emp> {

	@Override
	public int compare(Emp arg0, Emp arg1) {
		
		return (int) (arg0.getEmpSal()- arg1.getEmpSal());
	}
	

}
