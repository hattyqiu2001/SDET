package com.fannie.interfaces;

public class HomeLoan implements Loan {
	int loanAmount;
	

	public HomeLoan(int loanAmount) {
		super();
		this.loanAmount = loanAmount;
	}

	@Override
	public void submitLoan() {
		System.out.println("Home loan submitted");
		
	}

	@Override
	public void loanAmount() {
		System.out.println("Home Loan amount is" + loanAmount);
		
	}

	@Override
	public void foreclosure() {
		System.out.println("Home Loan foreclosure applied");
	}

	@Override
	public void foreclosure(int amount) {
		System.out.println("Home Loan foreclosure applied" + loanAmount);		
	}
	


}
