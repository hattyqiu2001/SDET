package com.fannie.interfaces;

import java.util.Arrays;

public class SortPrimitive {

	public static void main(String[] args) {
		
		int [] nums = new int[7];
		nums[0] = 10;
		nums[1] = 100;
		nums[2] = 130;
		nums[3] = 20;
		nums[4] = 4000;
		nums[5] = 49;
		nums[6] = 140;
		
		System.out.println("Original list");
		System.out.println("---------------------");
		for (int i: nums){
			System.out.println(i);
		}
		System.out.println("Sorted list");
		System.out.println("--------------------- ----------------");
		Arrays.sort(nums);
		
		for (int i: nums){
			System.out.println(i);
		}
			
	}
}
