package com.fannie.exception;

public class AccountClient {
public static void main(String[] args) {
	Account [] accs = new Account[4];
	accs [0] = new Account(1000);
	accs [1] = new Account(1892);
	accs [2] = new Account(1308);
	accs [3] = new Account(38);
	
	for (Account temp: accs){
		System.out.println(temp.getAccountId() + "," +temp.getBalance());
	}
	
}
}
