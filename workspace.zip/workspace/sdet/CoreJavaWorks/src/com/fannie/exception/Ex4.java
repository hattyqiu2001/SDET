package com.fannie.exception;

import java.io.IOException;

public class Ex4 {
	public static void submitLoan(String loanType, String custName, int amount) throws IOException{
		
	}
}
