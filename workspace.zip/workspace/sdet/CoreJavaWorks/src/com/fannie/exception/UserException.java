package com.fannie.exception;

public class UserException {
	public static void applyLoan (String loanType, int creditScore) throws CitiException, FannieException{
		if (loanType.equalsIgnoreCase("vehicle") && creditScore <400) {
			throw new CitiException("Sorry you credit score is too low, Vehicle loan not processed");
		}else if (loanType.equalsIgnoreCase("home") && creditScore <700) {
			throw new FannieException("Sorry you credit score is too low, Home loan not processed");
		}
	}
	public static void main(String[] args) {
		try {
			applyLoan("Vehicle", 500);
		} catch (CitiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FannieException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			applyLoan("home", 500);
		} catch (CitiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FannieException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}
class FannieException extends Exception{
	@Override
	public String getMessage() {

		return this.msg;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "+++" + this.msg + "++++";
	}

	private String msg;
	FannieException()
	{this.msg = "Fannie Exceptiion called...";
	}
	
	FannieException(String msg)
	{this.msg = msg;
	}
		
}

class CitiException extends Exception{
	@Override
	public String getMessage() {

		return this.msg;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "+++" + this.msg + "++++";
	}

	private String msg;
	CitiException()
	{this.msg = "Fannie Exceptiion called...";
	}
	
	CitiException(String msg)
	{this.msg = msg;
	}
	
}

