package com.fannie.exception;

public class StaticEx1 {
	public static int add(int a, int b){
		return a+b;
	}
	public static void hi(){
		System.err.println("you called hi");
	}
	static {System.out.println(" I am from static block...");
		
	}
	
	
	public static void main(String[] args) {
		int x = add(11,20);
	System.out.println("x is "+ x);
	hi();
	hello();
}
	public static void hello(){
		System.err.println("you called hello");
	}
}
