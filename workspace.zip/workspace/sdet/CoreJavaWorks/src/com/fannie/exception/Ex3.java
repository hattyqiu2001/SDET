package com.fannie.exception;

import javax.management.RuntimeErrorException;

public class Ex3 {
	
		
		public static void checkSalary(double sal, String name){
			try	{
			checkName("Pe");
			if (sal < 10000) {
				throw new ArithmeticException("Sorry salary is less, for " 
			+ name + "with salary " + sal);
			}else {
				System.out.println("salary under process "+ name +","+ sal);
			}
			}
			catch(RuntimeException re){
				throw new RuntimeException("sorry checking salary is not done "+ re);
			}
		}
		public static void main(String[] args) {		
			checkSalary(1000, "Sally");
			//checkName("Pe");
		}
		public static void checkName(String name){
		if (name.length() < 4)	{
			throw new RuntimeException("Sorry name can not be less than 4 ");
			}
		}

}
