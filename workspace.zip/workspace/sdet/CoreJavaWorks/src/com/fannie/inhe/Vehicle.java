package com.fannie.inhe;

public class Vehicle {
	public void move(){
		System.out.println("all vehicles move");
	}

}
