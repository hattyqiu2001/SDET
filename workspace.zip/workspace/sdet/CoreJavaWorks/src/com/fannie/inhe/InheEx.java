package com.fannie.inhe;
class A{
	A() {
		System.out.println("I am from A");
		
	}
}

class B extends A {
	B() {
		System.out.println("I am from B");
	}
	
	
}
class C extends B{
	
	C(){
		System.out.println("I am from C");
	}
	
}

public class InheEx {
	public static void main(String[] args) {
		C c = new C();
		
	}
}


