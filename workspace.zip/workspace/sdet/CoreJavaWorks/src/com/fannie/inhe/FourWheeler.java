package com.fannie.inhe;

public class FourWheeler extends Vehicle{
	public void steering(){
		System.out.println("all four wheelers having steering");
	}
}
