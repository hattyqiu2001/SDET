package com.fannie.Collections;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapEx1 {
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<String,Integer>();
		map.put("Allen", 1000);
		map.put("Lyndon", 12000);
		map.put("Luke", 24000);
		map.put("Allen", 80000);
		
		System.out.println(map.get("Allen"));
		
		Set set = map.entrySet();
		Iterator itr = set.iterator();
		
		while (itr.hasNext()){
			Map.Entry<String, Integer> temp = (Entry<String, Integer>)itr.next();
			System.out.println(temp.getKey() + ", " + temp.getValue());
		}
		
		
	}
}
