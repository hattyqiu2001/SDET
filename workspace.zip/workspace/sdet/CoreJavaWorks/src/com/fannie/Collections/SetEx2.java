package com.fannie.Collections;

import java.util.HashSet;

class Device{
	@Override
	public boolean equals(Object d) {
		Device temp = (Device)d;
		return this.dId == temp.dId && this.name.equals(temp.getName());
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.name.charAt(0);
	}

	private int dId;
	private String name;
	
	public int getdId() {
		return dId;
	}
	
	public Device(int dId, String name) {
		super();
		this.dId = dId;
		this.name = name;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Device [dId=" + dId + ", name=" + name + "]";
	}
}

public class SetEx2 {
	public static void main(String[] args) {
		HashSet<Device> devices = new HashSet<Device>();
		
		devices.add(new Device(10,"Laptop"));
		devices.add(new Device(11,"Computer"));
		devices.add(new Device(12,"Projector"));
		devices.add(new Device(13,"Presenter"));
		
		devices.add(new Device(10,"Laptop"));
		for (Device temp : devices){
			System.out.println(temp + ", " + temp.hashCode());
		}
	}
}
