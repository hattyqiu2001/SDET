package com.fannie.Collections;

import java.util.Vector;

public class ListEx4 {
	public static void main(String[] args) {
		Vector<String> v = new Vector<String>(5,3);
		v.ensureCapacity(12);
		
		System.out.println(v.capacity());
		System.out.println(v.size());
		
		v.add("one");
		v.add("two");
		v.add("three");
		v.add("four");
		v.add("five");
		v.add("six");
		v.add("seven");
		v.add("eight");
		v.add("nine");
		v.add("ten");
		v.add("eleven");
		
		System.out.println("after capa" +v.capacity());
		System.out.println("after size "+ v.size());
		
	}
	

}
