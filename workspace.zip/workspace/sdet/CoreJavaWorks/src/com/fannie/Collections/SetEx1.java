package com.fannie.Collections;

import java.util.HashSet;

public class SetEx1 {
public static void main(String[] args) {
	HashSet<String> set = new HashSet<String>();
	
	set.add("Andy");
	set.add("Amit");
	set.add("Ann");
	set.add("Betty");
	set.add("Amit");
	
	System.out.println(set);
	
	for (String temp: set){
		System.out.println(temp.hashCode());
	}
}
}
