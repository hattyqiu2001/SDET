package com.fannie.Collections;

import java.util.Set;
import java.util.TreeSet;

public class SetEx3 {
	public static void main(String[] args) {
		Set<String> set = new TreeSet<String>();
		
		set.add("Britt");
		set.add("Allen");
		set.add("Peter");
		set.add("Sam");
		set.add("Amit");
		set.add("Fusheng");
		
		System.out.println(set);
	}
}
