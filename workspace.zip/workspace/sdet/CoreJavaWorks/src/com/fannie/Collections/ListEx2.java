package com.fannie.Collections;

import java.awt.List;
import java.util.ArrayList;

public class ListEx2 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("hello");
		list.add("how");
		list.add("are");
		list.add("you");
		
		System.out.println("list is " +list);
		
		List newList = (List)list.subList(3, list.size());
		
		System.out.println(" new list is " +newList);
		
		
	}

}