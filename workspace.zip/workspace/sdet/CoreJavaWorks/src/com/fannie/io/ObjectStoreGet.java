package com.fannie.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectStoreGet {

	public static void storeObject(Customer cust) {
		ObjectOutputStream oos = null;

		try {
			oos = new ObjectOutputStream(new FileOutputStream(new File("Customer.ser")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			oos.writeObject(cust);
			oos.writeInt(cust.getCustId());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Data written....");
	}

	public static void getObject() throws FileNotFoundException, IOException{
		ObjectInputStream fis = new ObjectInputStream(new FileInputStream("Customer.ser"));
		
		Customer cust = null;
		try {
			cust = (Customer)fis.readObject();
			System.out.println(fis.readInt());
			System.out.println(cust);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException io){
			io.printStackTrace();
		}
		finally{
			
			fis.close();
		}
	}

	public static void main(String[] args) throws FileNotFoundException, IOException {

		Customer cu = new Customer(123, "Lee");
		storeObject(cu);
		getObject();

	}
}
