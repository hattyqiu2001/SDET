package com.fannie.io;

import java.io.File;
import java.io.IOException;

public class FileEx {
	public static void main(String[] args) {
		File f = new File("Sample.txt");
		try {
			System.out.println(f.createNewFile());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//f.delete();
		System.out.println(f.getAbsolutePath());
		System.out.println(f.canRead());
		System.out.println(f.getAbsolutePath());
		System.out.println(f.getTotalSpace());
		System.out.println(f.length());
		System.out.println(f.getPath());
		System.out.println(f.isDirectory());
	
	}

}
