package com.fannie.assignment;

public abstract class Vehicle {
	private String color;
	private int wheels;
	public abstract void move();
	public abstract void applyBreak();
	

	public Vehicle(String color, int wheels) {
		super();
		this.color = color;
		this.wheels = wheels;
	}

	public String getColor() {
		return color;
	}

	public int getWheels() {
		return wheels;
	}


}
