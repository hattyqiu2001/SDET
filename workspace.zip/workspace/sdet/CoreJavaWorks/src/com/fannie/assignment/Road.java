package com.fannie.assignment;

public class Road {
	public void move(Vehicle vehicle){
		vehicle.move();
		
	}
	
	public void slowDown(Vehicle vehicle){
		vehicle.applyBreak();
	}

}
