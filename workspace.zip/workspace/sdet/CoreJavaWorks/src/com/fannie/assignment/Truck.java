package com.fannie.assignment;

public class Truck extends Vehicle {
	private int engine;


	public Truck(String color, int wheels, int engine) {
		super(color, wheels);
		this.engine = engine;
	}

	public int getEngine() {
		return engine;
	}

	public void setEngine(int engine) {
		this.engine = engine;
	}

	@Override
	public void move() {
		System.out.println("Truck is moving" + " color is " + getColor() + " with "+ getWheels() + " Wheels " + "engine is " + getEngine());
		
	}

	@Override
	public void applyBreak() {
		// TODO Auto-generated method stub
		System.out.println("Truck is slowing down");
	}

}
