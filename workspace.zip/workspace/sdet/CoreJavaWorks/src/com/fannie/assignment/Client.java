package com.fannie.assignment;

public class Client {
	
	 public static void main(String[] args) {
		Vehicle[] vehicles = new Vehicle[5];
		
		vehicles[0] = new Car("blue", 4, true);
		vehicles[1] = new Car("yellow", 4, true);
		vehicles[2] = new Car("red", 4, false);
		vehicles[3] = new Truck("black", 4, 6);
		vehicles[4] = new Bus("white", 4, 50);
		
		for (Vehicle temp: vehicles){
			temp.move();
			temp.applyBreak();
			
		}
	}

}
