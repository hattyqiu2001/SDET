package com.fannie.assignment;

public class Bus extends Vehicle {
	private int numSeat;
	

	public Bus(String color, int wheels, int numSeat) {
		super(color, wheels);
		this.numSeat = numSeat;
	}

	public int getNumSeat() {
		return numSeat;
	}

	public void setNumSeat(int numSeat) {
		this.numSeat = numSeat;
	}

	@Override
	public void move() {
		System.out.println("Bus is moving" + " color is " + getColor() + " with "+ getWheels() + " Wheels " + "seat number is " + getNumSeat());
		
	}

	@Override
	public void applyBreak() {
		System.out.println("Bus is stopping");
		
		
	}
	

}
