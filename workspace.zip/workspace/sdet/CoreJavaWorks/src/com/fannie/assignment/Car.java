package com.fannie.assignment;

public class Car extends Vehicle{
	private boolean abs;

	public Car(String color, int wheels, boolean abs) {
		super(color, wheels);
		this.abs = abs;
	}

	

	public boolean isAbs() {
		return abs;
	}



	public void setAbs(boolean abs) {
		this.abs = abs;
	}



	@Override
	public void move() {
		System.out.println("car is moving" + " color is " + getColor() + " with "+ getWheels() + " Wheels " + "has abs is " + isAbs());
	}

	@Override
	public void applyBreak() {
		System.out.println("car is breaking");
		
	}

}
