package com.fannie.threads;

class BusinessLogic extends Thread {
	public void run() {
		for (int i = 0; i <= 500; i++) {
			System.out.println("I value " + i + " in Thread " + Thread.currentThread().getName());

		}
		System.out.println("Thread " + Thread.currentThread().getName() + "exiting .....");
	}

}

// if you have main method, then it is a thread
public class ThreadEx1 {
	public static void main(String[] args) {
		System.out.println("Thread is " + Thread.currentThread().getName());
		// min is 1
		// Norm is 5
		// Max is 10
		System.out.println("priority is " + Thread.currentThread().getPriority());

		BusinessLogic myJob1 = new BusinessLogic();

		// when you make a request for state() then the OS level thread is

		myJob1.setName("Michael");
		myJob1.setPriority(10);
		// myJob1.doMyJob();
		myJob1.start();

		BusinessLogic myJob2 = new BusinessLogic();
		myJob2.setName("Allen");
		myJob2.setPriority(1);
		myJob2.start();
		// myJob2.doMyJob();

		/*for (int i = 0; i <= 500; i++) {
			System.out.println("I value " + i + " in Thread " + Thread.currentThread().getName());
		}*/

		try {
			myJob1.join();
			myJob2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Main is exiting");
	}
}
