package com.fannie.threads;

class ThirdPartyBusiness{
	public void discount(){
	System.out.println("You run the business with us");
	}
}

class MyBusiness extends ThirdPartyBusiness implements Runnable{
	Thread t;
	MyBusiness(String name, int pri){
		t = new Thread(this, name);
		t.setPriority(pri);
		t.start();
		
	}

	@Override
	public void run() {
		for (int i = 0; i <= 500; i++) {
			System.out.println("I value " + i + " in Thread " + Thread.currentThread().getName());

		}
		System.out.println("Thread " + Thread.currentThread().getName() + "exiting .....");
	}
	
	
}
public class RunnableEx1 {
	public static void main(String[] args) {
		MyBusiness mi = new MyBusiness("Electronic", Thread.MAX_PRIORITY);
		MyBusiness m2 = new MyBusiness("Juice", Thread.NORM_PRIORITY);
		MyBusiness m3 = new MyBusiness("Pt Bottle", Thread.MIN_PRIORITY);
		mi.discount();
	}

}
