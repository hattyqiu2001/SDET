package com.fannie;

public class Customer {
	private int cID;
	private Name name;
	private double sal;
	public int getcID() {
		return cID;
	}
	public void setcID(int cID) {
		this.cID = cID;
	}
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Customer [cID=" + cID + ", name=" + name + ", sal=" + sal + "]";
	}
	
	


}
