package com.fannie;

public class Employee {
	private int empId = 100;
	private String empName ="Hatty";
	private double empSal = 1000;
	private Name name;
	
	
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		if (empName.length()<5){System.out.println("sorry the name should be min of 4 chars ");
			
		}
		else{
		this.empName = empName;
		}
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		if (empSal < 10000){
			System.out.println("sorry min sal to be 10,000");
		}else {
		
		this.empSal = empSal;
		}
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", name=" + name
				+ ", getName()=" + getName() + ", getEmpId()=" + getEmpId() + ", getEmpName()=" + getEmpName()
				+ ", getEmpSal()=" + getEmpSal() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
