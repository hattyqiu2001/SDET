package BankImpl;

import bank.Account;
import bank.CreditInterest;
import bank.DepositAcc;
import bank.Interest;

public class SavingsAcc implements DepositAcc,CreditInterest {

	@Override
	public void calcInt() {
		// TODO Auto-generated method stub

	}

	@Override
	public void createAcc() {
		// TODO Auto-generated method stub

	}

	@Override
	public void addMonthlyInt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addHalfYrlyInt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addAnnualInt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getBalance() {
		// TODO Auto-generated method stub
		
	}

}
