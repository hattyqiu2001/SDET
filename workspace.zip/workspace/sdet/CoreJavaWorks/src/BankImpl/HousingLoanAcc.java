package BankImpl;

import bank.DebitInterest;
import bank.LoanAcc;

public class HousingLoanAcc implements LoanAcc, DebitInterest {

	@Override
	public void createAcc() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcInt() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deductMonthlyInt() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deductHalfYrlyInt() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deductAnnualInt() {
		// TODO Auto-generated method stub

	}

	@Override
	public void repayPrincipal() {
		// TODO Auto-generated method stub

	}

	@Override
	public void payInterest() {
		// TODO Auto-generated method stub

	}

	@Override
	public void payPartialPrincipal() {
		// TODO Auto-generated method stub

	}

}
