package accountclient;

import BankImpl.HousingLoanAcc;
import bank.Account;

public class AccountClient {
	public static void main(String[] args) {
		Account myAccount = new HousingLoanAcc();
		
	}
}
