package bank;

public interface LoanAcc extends Account {
	
	public abstract void repayPrincipal ();
	public abstract void payInterest ();
	public abstract void payPartialPrincipal ();
}
