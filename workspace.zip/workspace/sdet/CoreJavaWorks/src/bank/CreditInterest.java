package bank;

public interface CreditInterest extends Interest {

	public abstract void addMonthlyInt();
	public abstract void addHalfYrlyInt();
	public abstract void addAnnualInt();
}
