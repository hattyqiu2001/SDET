package bank;

public interface DepositAcc extends Account {
	public abstract void withdraw (); 
	public abstract void deposit ();
	public abstract void getBalance();

}
