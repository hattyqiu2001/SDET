package bank;

public interface Account {
	public static final String Savings = null;
	public static final String Fixed = null;
	public static final String PersonalLoan = null;
	public static final String HousingLoan = null;
	public abstract void createAcc();
}
