package bank;

public interface Interest {
	public static final double savingsAccount = 0.00;
	public static final double fixedDepositAccount = 0.00;
	public static final double personalLoanAccount = 0.00;          
	public static final double housingLoanAccount = 0.00;
	
	public abstract void calcInt();
}
