package bank;

public interface DebitInterest extends Interest {
	public abstract void deductMonthlyInt();
	public abstract void deductHalfYrlyInt();
	public abstract void deductAnnualInt();


}
