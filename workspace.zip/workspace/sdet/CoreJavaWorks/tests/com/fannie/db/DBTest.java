package com.fannie.db;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.fannie.dbworks.EmpBean;
import com.fannie.dbworks.EmployeeDB;

public class DBTest {

	static EmployeeDB edb = null;
	static EmpBean bean = null;
	@BeforeClass	
	public static void empObjInit(){
		
		System.out.println("before class called");
		 edb = new EmployeeDB();
		bean = new EmpBean();
		
	}
	@Before
	public void beforeAllMethod(){
		System.out.println("I am from before all method");
	}
	@After
	public void afterAllMethod(){
		System.out.println("I am from after all method");
	}
	
	// to make the method as test case, it has to be annotated by @test
	@Test(timeout=500)
	public  void insertEmployeePassTest() {
		
		assertEquals("Testing to check Employee Pass", true, edb.insertEmployee(bean));
		//edb.insertEmployee(bean);	
		
	}
	
	@Test
	public void insertEmployeeFailTest() {
		assertNotEquals("Testing to check Employee Fail", false, edb.insertEmployee(bean));
		//edb.insertEmployee(bean);	
		
	}

}
