import org.junit.Test;

public class testDemos {
	
	
	@Test
	public void tc_CheckIt(){
		System.out.println("All good?");
	}
	

}
