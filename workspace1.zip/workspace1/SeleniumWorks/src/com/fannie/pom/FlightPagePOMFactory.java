package com.fannie.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FlightPagePOMFactory {
	WebDriver driver;
	public FlightPagePOMFactory(WebDriver driver){
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
		// TODO Auto-generated metho
	
	@FindBy(id = "flight-origin-hp-flight")
	WebElement flyingFrom;
	@FindBy(id = "flight-destination-hp-flight")
	WebElement flyingTo;
	
	@FindBy(id= "flight-departing-hp-flight")
	WebElement departingDate;
	
	@FindBy(id = "flight-returning-hp-flight")
	WebElement returnDate;
	
	@FindBy(xpath = "//*[@id='gcw-flights-form-hp-flight']/div[7]/label/button")
	WebElement searchBtn;
	
	@FindBy(id = "tab-flight-tab-hp")
	WebElement flightTab;
	public void clickFlightTable(){
		flightTab.click();
	}
	public void sendFlyingFrom(String src){
		flyingFrom.sendKeys(src);
	}
	public void sendFlyingTo(String dest){
		flyingTo.sendKeys(dest);
	}
	public void sendDepartureDate(String date)	{
		departingDate.click();
		departingDate.clear();
		departingDate.sendKeys(date);
	}
	public void sendReturnDate(String date)	{
		returnDate.click();
		returnDate.clear();
		returnDate.sendKeys(date);
	}
	public void clickSearchButton(){
		searchBtn.click();
	}
	public void clickFlightButton(){
		flightTab.click();
	}
		
	
}
