package com.fannie.utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTypes {

	WebDriver driver = null;
	public WaitTypes (WebDriver driver){
		this.driver = driver;
	}
	public WebElement waitForElement(By locator, int timeout){
			
			try {
				WebDriverWait wait = new WebDriverWait(driver, timeout);
				WebElement email = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	
		}
	public WebElement clickWhenReady(By locator, int timeout){
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeout);
			WebElement email = wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
