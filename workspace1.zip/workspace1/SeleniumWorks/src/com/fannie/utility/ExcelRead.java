package com.fannie.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead {
	
	public static void main(String[] args) {
		String path = "C:\\Users\\Huser\\Downloads\\Download All Attachments [SPAM-LOW  Excel Fil]\\sample.xlsx";
		String sheetName = "Sheet1";
		XSSFSheet sheet = getSheet(path, sheetName);	
	}
	
	public static XSSFSheet getSheet(String path, String sheetName){
		XSSFSheet sheet =null;
		
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(path));
			sheet = workbook.getSheet(sheetName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sheet;
	}

}
