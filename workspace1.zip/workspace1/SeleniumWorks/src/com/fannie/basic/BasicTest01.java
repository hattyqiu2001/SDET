package com.fannie.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BasicTest01 {
	public static void main(String[] args) {
		WebDriver driver;
		String baseUrl = "http://google.com";
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");
		// we want to test on chrome browser
		driver = new ChromeDriver();
		driver.get(baseUrl);
		
		/*System.setProperty("webdriver.ie.driver", "C:\\Users\\Huser\\Downloads\\IEDriverServer_Win32_3.2.0\\IEDriverServer.exe");
		// we want to test on ie browser
		driver = new InternetExplorerDriver();*/
		//driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.findElement(By.id("lst-ib")).sendKeys("best places to visit in virginia");
		driver.findElement(By.name("btnG")).click();
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.quit();
		
		
	}
	

}
