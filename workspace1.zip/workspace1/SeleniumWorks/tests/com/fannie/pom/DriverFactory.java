package com.fannie.pom;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverFactory {
	static WebDriver driver;
	public static WebDriver  getDriver(String browser){
		if (browser.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			return driver;
		}
		else if(browser.equals("ie")){
			// to do
		}
		else if(browser.equals("firefox")){
			
		}
		return null;
	}
}
