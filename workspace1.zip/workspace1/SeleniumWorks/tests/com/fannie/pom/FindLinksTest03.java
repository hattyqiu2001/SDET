package com.fannie.pom;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FindLinksTest03 {
	
	private static WebDriver driver;
	private String baseUrl;
	// by doing @BeofreClass the method is loaded only once per jUnit test case/s
	@BeforeClass
	public static void beforeClass(){
		driver = DriverFactory.getDriver("chrome");
	}
	
	@After
	public void tearDown() throws Exception {
		Thread.sleep(4000);
		driver.quit();
	}
	@Before
	public void setUp(){
		baseUrl = "http://expedia.com";
		driver.get(baseUrl);
	}
	
	@Test
	public void test() throws Exception {
		//imp for get all the links
		List<WebElement> list = clickableLinks();
		for (WebElement temp: list){
			 String href = temp.getAttribute("href");
			System.out.println("URL " + href + " response -?>" + linkStatus(new URL(href)));
		}
	}
	public static List<WebElement> clickableLinks(){
		List<WebElement> linksToClick = new ArrayList<WebElement>();
		List<WebElement> anchorElements = driver.findElements(By.tagName("a"));
		anchorElements.addAll(driver.findElements(By.tagName("img")));
		for (WebElement temp: anchorElements){
			if (temp.getAttribute("href") != null){
					linksToClick.add(temp);
			}
			
		}
		return linksToClick;
	}
	public static String linkStatus(URL url){
		try {
			HttpURLConnection connection = (HttpsURLConnection)url.openConnection();
			connection.connect();
			String res = connection.getResponseMessage();
			connection.disconnect();
			return res;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
}
