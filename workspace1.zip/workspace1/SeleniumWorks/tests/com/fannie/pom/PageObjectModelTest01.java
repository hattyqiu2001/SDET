package com.fannie.pom;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageObjectModelTest01 {
	private WebDriver driver;
	private String baseUrl;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();

		baseUrl = "http://expedia.com";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(4000);
		driver.quit();
	}


@Test
public void test() throws Exception{
	driver.get(baseUrl);
	FlightPagePOM.clickFlightTab(driver);
	FlightPagePOM.flyingFromTextBox(driver, "New York, NY (NYC-All Airports)");
	FlightPagePOM.flyingToTextBox(driver, "Hong Kong, Hong Kong (HKG-Hong Kong Intl.)");
	FlightPagePOM.departDateField(driver, "03/09/2017");
	FlightPagePOM.returnDateField(driver, "03/11/2017");
	FlightPagePOM.clickSearchTab(driver);
	
	Thread.sleep(8000);
}
}
