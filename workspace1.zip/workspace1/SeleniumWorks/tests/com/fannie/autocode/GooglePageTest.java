package com.fannie.autocode;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GooglePageTest {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");

    driver = new ChromeDriver();
    baseUrl = "https://accounts.google.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testCase02() throws Exception {
    driver.get(baseUrl + "/ServiceLogin?hl=en&passive=true&continue=https://www.google.com/#identifier");
    driver.findElement(By.id("Email")).clear();
    driver.findElement(By.id("Email")).sendKeys("123@gmail.com");
    driver.findElement(By.id("next")).click();
  }

  @After
  public void tearDown() throws Exception {
	  
	  
	  Thread.sleep(3000);
    driver.quit();
  }
}