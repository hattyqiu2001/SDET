package com.fannie.testcase;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class TestCase04 {
	private WebDriver driver;
	private String baseUrl;
	private String baseUrl1;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		 baseUrl = "https://www.expedia.com";
		 baseUrl1 = "http://html.com/attriutes/select-multiple/";
		 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() throws Exception {

		Thread.sleep(3000);
		driver.quit();
	}

	@Test
	public void test() {
		driver.get(baseUrl);
		WebElement e1 = driver.findElement(By.id("package-rooms-hp-package"));
		Select select1 = new Select(e1);
		
		List<WebElement> options = select1.getOptions();
		System.out.println("Number of option for e1 ->" + options.size());
		for (int i = 0; i<options.size(); i++){
			System.out.println(select1.getAllSelectedOptions().get(i).getText());
		}

		// select by val
        
        select1.selectByValue("2");
        
        //select by index
        select1.selectByIndex(2);
	}
	
	@Test 
	public void multiSelectTest() throws Exception{
		driver.get(baseUrl1);
		
		Select select = new Select (driver.findElement(By.xpath("//*[@id='wrapper']/article/section/div[2]/select")));
		select.selectByValue("American");
		select.selectByValue("Greater");
		
		Thread.sleep(3000);
		select.deselectByValue("Greater");
		
		Thread.sleep(3000);
		select.deselectByValue("American");
		
		
	}

}
