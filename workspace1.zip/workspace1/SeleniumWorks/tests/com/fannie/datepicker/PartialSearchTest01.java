package com.fannie.datepicker;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fannie.generic.GenericMethod01;

public class PartialSearchTest01 {

	private WebDriver driver;
	private String baseUrl;
	private GenericMethod01 gm1 ; 
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		gm1 = new GenericMethod01(driver);
		baseUrl = "http://expedia.com";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(4000);
		driver.quit();
	}


@Test
public void test() throws Exception{
	driver.get(baseUrl);
	String partialString = "new yor";
	
	// assume that we are connecting to Db to gt teh list of the 
	String location = "New Orleans, LA (MSY-All Airports)";
	
	driver.findElement(By.id("tab-flight-tab-hp")).click();
	
	driver.findElement(By.id("flight-origin-hp-flight")).sendKeys(partialString);
	List<WebElement> elements= 
		driver.findElements(By.xpath("//li[@class='results-item']"));
	
	System.out.println("Locations got is ->" +elements.size());
	

	for (WebElement element :elements){
		System.out.println (element.getText());
	}
	
	Thread.sleep(20000);
	
	for (WebElement element :elements){
		if(element.getText().equals(location)){
			element.click();
			}
		}
	
}
	
}