package com.fannie.implicitexplicit;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplicitTest01 {
	
	private WebDriver driver;
	private String baseUrl;
	private String baseUrl1;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		 baseUrl = "http://cinetalenters.com/#/login";
		 baseUrl1 = "http://html.com/attriutes/select-multiple/";
		 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() throws Exception {

		Thread.sleep(3000);
		driver.quit();
	}


	@Test
	public void test() {
		
		driver.get(baseUrl);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/div[3]/h4/a[2]/span")).click();
		driver.findElement(By.id("email")).sendKeys("testing@gmail.com");
		driver.findElement(By.id("password")).sendKeys("123");
	
	
	}

}
