package com.fannie.implicitexplicit;

import java.util.concurrent.TimeUnit;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fannie.utility.WaitTypes;

public class ExplicitWaitGeneric {
	private WebDriver driver;
	private String baseUrl;
	private String baseUrl1;
	private WaitTypes wt;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		baseUrl = "http://naveenks.com/selenium/RegForm.html";
		 wt = new WaitTypes(driver);
		 
		driver.manage().window().maximize();
		
	}

	@After
	public void tearDown() throws Exception {

		Thread.sleep(3000);
		driver.quit();
	}
	@Test
	public void test() {
		
		driver.get(baseUrl);
		WebElement email = wt.waitForElement(By.id("uname"),5);
		email.sendKeys("hello@gmail.com");
		WebElement pwd = wt.waitForElement(By.id("pwd"), 6);
		pwd.sendKeys("pwd123");
		
		wt.clickWhenReady(By.id("submitBtn"), 3);
	
	
	}
}
