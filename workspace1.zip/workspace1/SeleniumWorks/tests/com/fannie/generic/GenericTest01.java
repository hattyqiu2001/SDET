package com.fannie.generic;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GenericTest01 {
	
	private WebDriver driver;
	private String baseUrl;
	private String baseUrl1;
	private GenericMethod01 gm1;
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Huser\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		
		gm1 = new GenericMethod01(driver);
		baseUrl = "http://naveenks.com/selenium/RegForm.html";
		 baseUrl1 = "http://html.com/attriutes/select-multiple/";
		 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() throws Exception {

		Thread.sleep(3000);
		driver.quit();
	}
	@Test
	public void test() throws Exception {
		driver.get(baseUrl);
		WebElement inputElement = gm1.getElement("inputEmail", IType.ID);
		inputElement.sendKeys("john@doc.com");
		if (gm1.checkSingleFound("inputPassword",IType.ID)){
				
		gm1.getElement("inputPassword", IType.ID).sendKeys("helloworld");
	}
		Thread.sleep(2000);
		gm1.getElement("confirmPassword", IType.ID).sendKeys("hiworld");
		Thread.sleep(2000);
		inputElement.clear();
		inputElement.sendKeys("peter@england.com");
	
	}

}
