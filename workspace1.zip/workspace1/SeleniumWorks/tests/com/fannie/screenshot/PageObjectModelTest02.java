package com.fannie.screenshot;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.fannie.pom.DriverFactory;
import com.fannie.pom.FlightPagePOMFactory;

public class PageObjectModelTest02 {
	
	private static WebDriver driver;
	private FlightPagePOMFactory flightFactory;
	private String baseUrl;
	// by doing @BeofreClass the method is loaded only once per jUnit test case/s
	@BeforeClass
	public static void beforeClass(){
		driver = DriverFactory.getDriver("chrome");
	}
	
	@After
	public void tearDown() throws Exception {
		Thread.sleep(4000);
		driver.quit();
	}
	@Before
	public void setUp(){
		flightFactory = new FlightPagePOMFactory(driver);
		baseUrl = "http://expedia.com";
		driver.get(baseUrl);
	}

	@Test
	public void test() {
		flightFactory.clickFlightTable();
		flightFactory.sendFlyingFrom("New York, NY (NYC-All Airports)");
		flightFactory.sendFlyingTo("Hong Kong, Hong Kong (HKG-Hong Kong Intl.)");
		flightFactory.sendDepartureDate("03/09/201");
		flightFactory.sendReturnDate("03/19/201");
		flightFactory.clickSearchButton();
		}

}
