package com.fannie.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fannie.entity.Message;

/*1. Write a restful service for doing CRUD operation on the given data model 



The application should have below services 
*) Save a message
*) Update a message with id
*) Delete a message with id 
*) Delete message with author 
*) Get all messages 
*) Get message based on id 
*) Get Message based on the author, if there are more than one message with the same author it should show 
*/


public class MessageService {
	static Map<Long, Message> messages = new HashMap<Long, Message>();
	
	public MessageService(){
		System.out.println("Constructor invoked for Message Service... ");

		Message m1 = new Message();
		m1.setMessageId(101);
		m1.setMsg("Its beautiful day outside, how is your day");
		m1.setAuthor("James");
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd--MMM-yyyy");
		String dateInString = "22-FEB-2017";
		Date date= null;
		try {
			date = sdf.parse(dateInString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		m1.setDate(date);
		
		
		messages.put(101L, m1);
	}
	public Message saveMessage(Message message){
		messages.put((long)message.getMessageId(), message);
		return message;
		
	}
	public Message getMessage(long messageId){
		return messages.get(messageId);
	}
	
	public List<Message> getAllMessages(){
		return new ArrayList<Message>(messages.values());
	}
	
	public Message insertMessage(Message message){
		messages.put( (long)message.getMessageId(), message);
		return message;
	}
	
	public Message updateMessage(Message message){
		messages.put( (long)message.getMessageId(), message);
		return message;
	}

	public String deleteMessage (long messageId){
		if(this.getMessage(messageId)!=null){
			messages.remove(messageId);
			return "Message Deleted "+ messageId;
		}else{
			return "Sorry Message Not Found: " + messageId;
		}
	}
	/*public String deleteMessage (String author){
		if(this.getAuthor()==author){
			messages.remove(messageId);
			return "Message Deleted "+ messageId;
		}else{
			return "Sorry Message Not Found: " + messageId;
		}
	}*/
}










