package com.fannie.entity;

import java.util.Date;

/*1. Write a restful service for doing CRUD operation on the given data model 
{
    messageId:101, 
    author:'James', 
    message:'Its beautiful day outside, how is your day', 
    date: '23-FEB-2017'
}


The application should have below services 
*) Save a message
*) Update a message with id
*) Delete a message with id 
*) Delete message with author 
*) Get all messages 
*) Get message based on id 
*) Get Message based on the author, if there are more than one message with the same author it should show 

*/public class Message {
	private int messageId;
	private String msg;
	private  String author;
	private Date date;
	
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getDate(){
		return date;
	}
	public void setDate(Date date){
		this.date = date;
	}
	
	@Override
	public String toString() {
		return "Message [messageId=" + messageId + ", msg=" + msg + ", author="
				+ author + "]";
	}

}
